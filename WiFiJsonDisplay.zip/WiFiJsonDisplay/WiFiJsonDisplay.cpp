#include <WiFiJsonDisplay.h>

// Create an instance
WiFiJsonDisplay display;

void setup() {
  Serial.begin(9600);
  
  // Initialize display
  display.begin();
  
  // Set WiFi credentials
  display.setWiFiCredentials("YOUR_WIFI_SSID", "YOUR_WIFI_PASSWORD");
  
  // Set API endpoint
  display.setAPIEndpoint("api.example.com", "/data.json");
}

void loop() {
  // Fetch and display JSON using default display method
  display.fetchAndDisplayJSON();
  
  delay(30000); // Update every 30 seconds
}