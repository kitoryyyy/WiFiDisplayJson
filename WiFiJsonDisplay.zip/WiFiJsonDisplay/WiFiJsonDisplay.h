#ifndef WIFI_JSON_DISPLAY_H
#define WIFI_JSON_DISPLAY_H

#include <Arduino.h>
#include <SPI.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>

// Choose the appropriate WiFi library based on your hardware
#if defined(ARDUINO_SAMD_NANO_33_IOT)
  #include <WiFiNINA.h>
#elif defined(ESP8266)
  #include <ESP8266WiFi.h>
#elif defined(ESP32)
  #include <WiFi.h>
#else
  // Default to WiFiNINA, but user might need to change this
  #include <WiFiNINA.h>
#endif

#include <ArduinoJson.h>

class WiFiJsonDisplay {
  private:
    // Display configuration
    Adafruit_SSD1306* _display;
    int _screen_width;
    int _screen_height;
    int _oled_reset;
    int _screen_address;
    
    // WiFi configuration
    const char* _ssid;
    const char* _password;
    
    // API endpoint configuration
    const char* _host;
    const char* _path;
    int _port;
    
    // JSON document size
    size_t _jsonCapacity;
    
    // Internal methods
    bool connectWiFi();
    String fetchData();
    
  public:
    WiFiJsonDisplay(int screen_width = 128, int screen_height = 64, 
                   int oled_reset = -1, int screen_address = 0x3C);
    ~WiFiJsonDisplay();
    
    // Setup methods
    bool begin();
    void setWiFiCredentials(const char* ssid, const char* password);
    void setAPIEndpoint(const char* host, const char* path, int port = 80);
    void setJsonCapacity(size_t capacity);
    
    // Display methods
    void clearDisplay();
    void showText(const char* text, int x = 0, int y = 0, int size = 1);
    void showIP();
    
    // Data methods
    bool fetchAndDisplayJSON(void (*customDisplayFunction)(JsonDocument&, Adafruit_SSD1306*) = NULL);
    
    // Direct access to display if needed
    Adafruit_SSD1306* getDisplay();
};

#endif // WIFI_JSON_DISPLAY_H

// WiFiJsonDisplay.cpp
#include "WiFiJsonDisplay.h"

WiFiJsonDisplay::WiFiJsonDisplay(int screen_width, int screen_height, 
                               int oled_reset, int screen_address) {
  _screen_width = screen_width;
  _screen_height = screen_height;
  _oled_reset = oled_reset;
  _screen_address = screen_address;
  _display = new Adafruit_SSD1306(_screen_width, _screen_height, &Wire, _oled_reset);
  
  _ssid = NULL;
  _password = NULL;
  _host = NULL;
  _path = NULL;
  _port = 80;
  _jsonCapacity = 512; // Default capacity
}

WiFiJsonDisplay::~WiFiJsonDisplay() {
  if (_display != NULL) {
    delete _display;
  }
}

bool WiFiJsonDisplay::begin() {
  if (!_display->begin(SSD1306_SWITCHCAPVCC, _screen_address)) {
    Serial.println(F("SSD1306 allocation failed"));
    return false;
  }
  
  _display->clearDisplay();
  _display->setTextSize(1);
  _display->setTextColor(SSD1306_WHITE);
  _display->setCursor(0, 0);
  _display->println(F("Display initialized"));
  _display->display();
  
  return true;
}

void WiFiJsonDisplay::setWiFiCredentials(const char* ssid, const char* password) {
  _ssid = ssid;
  _password = password;
}

void WiFiJsonDisplay::setAPIEndpoint(const char* host, const char* path, int port) {
  _host = host;
  _path = path;
  _port = port;
}

void WiFiJsonDisplay::setJsonCapacity(size_t capacity) {
  _jsonCapacity = capacity;
}

void WiFiJsonDisplay::clearDisplay() {
  _display->clearDisplay();
  _display->display();
}

void WiFiJsonDisplay::showText(const char* text, int x, int y, int size) {
  _display->clearDisplay();
  _display->setTextSize(size);
  _display->setCursor(x, y);
  _display->println(text);
  _display->display();
}

void WiFiJsonDisplay::showIP() {
  _display->clearDisplay();
  _display->setCursor(0, 0);
  _display->println(F("WiFi connected!"));
  _display->println(F("IP: "));
  _display->println(WiFi.localIP());
  _display->display();
}

bool WiFiJsonDisplay::connectWiFi() {
  if (_ssid == NULL || _password == NULL) {
    Serial.println(F("WiFi credentials not set"));
    return false;
  }
  
  WiFi.begin(_ssid, _password);
  
  // Wait for connection with timeout
  unsigned long startTime = millis();
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
    
    // Timeout after 20 seconds
    if (millis() - startTime > 20000) {
      Serial.println(F("\nWiFi connection timeout"));
      return false;
    }
  }
  
  Serial.println(F("\nWiFi connected"));
  return true;
}

String WiFiJsonDisplay::fetchData() {
  if (_host == NULL || _path == NULL) {
    Serial.println(F("API endpoint not set"));
    return "";
  }
  
  WiFiClient client;
  
  Serial.print(F("Connecting to "));
  Serial.println(_host);
  
  if (!client.connect(_host, _port)) {
    Serial.println(F("Connection failed"));
    return "";
  }
  
  // Send HTTP request
  client.print(String("GET ") + _path + " HTTP/1.1\r\n" +
               "Host: " + _host + "\r\n" +
               "Connection: close\r\n\r\n");
  
  // Wait for response with timeout
  unsigned long timeout = millis();
  while (client.available() == 0) {
    if (millis() - timeout > 5000) {
      Serial.println(F("Client Timeout"));
      client.stop();
      return "";
    }
  }
  
  // Skip HTTP headers
  char endOfHeaders[] = "\r\n\r\n";
  if (!client.find(endOfHeaders)) {
    Serial.println(F("Invalid response"));
    return "";
  }
  
  // Read the content
  String content = client.readString();
  client.stop();
  
  return content;
}

bool WiFiJsonDisplay::fetchAndDisplayJSON(void (*customDisplayFunction)(JsonDocument&, Adafruit_SSD1306*)) {
  // Connect to WiFi if not connected
  if (WiFi.status() != WL_CONNECTED) {
    if (!connectWiFi()) {
      showText("WiFi connection failed", 0, 0);
      return false;
    }
  }
  
  // Fetch data
  String jsonData = fetchData();
  if (jsonData.length() == 0) {
    showText("Failed to fetch data", 0, 0);
    return false;
  }
  
  // Parse JSON
  DynamicJsonDocument doc(_jsonCapacity);
  DeserializationError error = deserializeJson(doc, jsonData);
  
  if (error) {
    Serial.print(F("deserializeJson() failed: "));
    Serial.println(error.c_str());
    showText("JSON parsing failed", 0, 0);
    return false;
  }
  
  // Display the data
  _display->clearDisplay();
  _display->setCursor(0, 0);
  
  // If a custom display function is provided, use it
  if (customDisplayFunction != NULL) {
    customDisplayFunction(doc, _display);
  } 
  // Otherwise use a default display method
  else {
    // Just show the first few key-value pairs as an example
    // In a real implementation, you'd want to customize this for your data
    JsonObject root = doc.as<JsonObject>();
    int y = 0;
    for (JsonPair kv : root) {
      if (y < _screen_height - 10) {  // Make sure we don't go off-screen
        _display->setCursor(0, y);
        _display->print(kv.key().c_str());
        _display->print(": ");
        
        // For simple values, display them
        if (kv.value().is<const char*>()) {
          _display->println(kv.value().as<const char*>());
        } 
        else if (kv.value().is<int>()) {
          _display->println(kv.value().as<int>());
        }
        else if (kv.value().is<float>()) {
          _display->println(kv.value().as<float>());
        }
        else {
          _display->println("...");
        }
        
        y += 10;  // Move down for next line
      }
    }
  }
  
  _display->display();
  return true;
}

Adafruit_SSD1306* WiFiJsonDisplay::getDisplay() {
  return _display;
}